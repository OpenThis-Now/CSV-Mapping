# Mapping Bridge - UI Design Reference

## 📋 Översikt

**App-namn:** Mapping Bridge

**Syfte:** Ett verktyg för att matcha produkter från kunders import-filer (CSV eller PDF) med en produktdatabas, med hjälp av AI för komplex matchning och automatisering.

**Användare:** Interna användare som arbetar med produktdatamapping mellan kunders produktlistor och företagets master-databas.

---

## 🎨 Design System

### Färgschema

**Primary:**
- Brand Color: `#0ea5e9` (Sky Blue)
- Används för: primära knappar, aktiva tabs, framhävning

**Status Colors:**
- **Green** (`green-100`, `green-600`, etc.): Approved, Success, Completed
- **Red** (`red-100`, `red-600`, etc.): Rejected, Errors, Delete actions
- **Blue** (`blue-100`, `blue-600`, etc.): Pending, In Progress, Information
- **Yellow** (`yellow-100`, `yellow-600`, etc.): Worklist, Needs attention
- **Gray** (`gray-50`, `gray-100`, etc.): Neutral, Backgrounds, Borders

### Typografi & Spacing

- **Rundade hörn:** `rounded-2xl` (16px) för cards och större element
- **Rundade hörn:** `rounded-xl` (12px) för inputs och mindre element
- **Rundade hörn:** `rounded-full` för pills/chips och indikatorer
- **Font:** System default (Tailwind defaults)
- **Spacing:** Tailwind's standard spacing scale

### Komponenter (Custom CSS Classes)

Definierade i `src/index.css`:

```css
.btn { 
  @apply inline-flex items-center rounded-2xl px-4 py-2 
         font-medium shadow-sm bg-sky-500 text-white 
         hover:bg-sky-600 disabled:opacity-50; 
}

.card { 
  @apply bg-white shadow-sm rounded-2xl border p-4; 
}

.chip { 
  @apply inline-flex items-center px-2 py-1 
         text-xs rounded-full border; 
}
```

---

## 🏗️ App-struktur

### Huvudlayout

**Sticky Header (top navigation):**
- Logo/App name: "Mapping Bridge" (vänster)
- Navigation tabs (mitten)
- AI processing indicator (höger, visas vid aktivitet)
- Project selector (höger)

**Navigation Tabs:**
1. **Projects** - Alltid tillgänglig
2. **Databases** - Alltid tillgänglig
3. **Customer Import** - Kräver vald project + databas
4. **Matching** - Kräver project + databas + import
5. **AI reviews** - Kräver project + databas + import
6. **Export** - Kräver project + databas + import
7. **Rejected Products** - Kräver project + databas + import
8. **Info** - Alltid tillgänglig

**Tabs blir disabled** (grayed out, `opacity-50 cursor-not-allowed`) om förutsättningar inte är uppfyllda.

---

## 📱 Sidor & Funktioner

### 1. Projects (Projects.tsx)
**Funktion:** Skapa, visa och hantera projekt. Varje projekt är en mappningsession.

**Innehåll:**
- Input för att skapa nytt projekt
- Lista över befintliga projekt (cards)
- Varje projekt-card visar:
  - Projektnamn (edit-funktion)
  - Status & aktiv databas
  - Progress bar med detaljer:
    - Approved (grön)
    - Worklist (gul)
    - Rejected (röd)
    - Pending (grå)
  - Total produktantal
  - "Open" eller "Selected ✓" knapp
  - Delete-knapp

### 2. Databases (Databases.tsx)
**Funktion:** Hantera produktdatabaser som används för matching.

**Innehåll:**
- Upload-area för nya databaser (CSV)
- Lista över befintliga databaser
- Koppla databas till projekt

### 3. Customer Import (Import.tsx)
**Funktion:** Importera kundens produktlista (CSV).

**Innehåll:**
- Upload-area för CSV-filer
- Lista över importerade filer
- Välj aktiv import för projektet
- CSV preview/editor

### 4. PDF Import (PDFImport.tsx)
**Funktion:** Importera produktlistor från PDF-filer (SDS/Safety Data Sheets).

**Innehåll:**
- Upload-area för PDF-filer (multi-file support)
- Progress indicator för PDF-processing
- Lista över processade PDFs

### 5. Matching (Match.tsx)
**Funktion:** Kör automatisk matchning mellan import och databas.

**Innehåll:**
- Knappar för att köra matching
- Progress indicators
- Matchningsresultat i tabell-format
- Status för varje rad (auto-approved, pending, rejected, etc.)
- Bulk actions för att godkänna/avvisa

### 6. AI reviews (AIDeep.tsx)
**Funktion:** Skicka osäkra matchningar till AI för djupare analys.

**Innehålt:**
- Status för AI-processing
- Queue-status (hur många i kö)
- AI's reasoning för varje matchning
- Godkänn/avvisa AI-förslag

### 7. Export (Export.tsx)
**Funktion:** Exportera färdiga mappningar.

**Innehåll:**
- Knapp för att generera export
- Ladda ner CSV med mappade produkter

### 8. Rejected Products (RejectedProducts.tsx)
**Funktion:** Hantera produkter som inte kunde matchas.

**Innehåll:**
- Lista över rejected products
- Export-funktion för rejected items

### 9. Info (Info.tsx)
**Funktion:** Information om applikationen och instruktioner.

---

## 🔧 UI-komponenter (Återanvändbar)

### DataGrid (DataGrid.tsx)
Tabell-komponent baserad på TanStack React Table.
- Sticky header
- Hover-effects
- Sorterbara kolumner

### UploadArea (UploadArea.tsx)
Drag & drop upload-yta.
- Stödjer både drag-drop och file picker
- Visuell feedback vid drag (border blir blå)
- Support för CSV och PDF

### DetailedProgressBar (DetailedProgressBar.tsx)
Segmenterad progress bar som visar olika statusar.
- Grön: Approved
- Gul: Worklist
- Röd: Rejected
- Grå: Pending
- Tooltips med exakta siffror

### AIQueueStatus (AIQueueStatus.tsx)
Visar status för AI-processing queue.
- Antal items i kö
- Processing status
- Progress indicator

### BulkActionBar (BulkActionBar.tsx)
Action bar för bulk operations på valda rader.
- Approve all
- Reject all
- Send to AI

### Toast (Toast.tsx)
Toast notifications för feedback.
- Success, Error, Info states
- Auto-dismiss

### CountryFlag (CountryFlag.tsx)
Visar landflagga baserat på landskod.

---

## 🎯 Användarflöde

**Typiskt arbetsflöde:**

1. **Skapa projekt** → Användaren skapar ett nytt projekt
2. **Välj databas** → Koppla en produktdatabas till projektet
3. **Importera** → Ladda upp kundens produktlista (CSV eller PDF)
4. **Matcha** → Kör automatisk matching
5. **AI review** → Skicka osäkra matchningar till AI
6. **Granska** → Manuellt granska och godkänn/avvisa
7. **Exportera** → Ladda ner färdig mapping

---

## 📦 Dependencies (från package.json)

**UI-bibliotek:**
- React 18.2
- TanStack React Table 8.12 (för tabeller)
- Radix UI (dropdown menu, toast)
- Lucide React 0.441 (ikoner)
- Tailwind CSS 3.4.6

**Utilities:**
- Axios (API calls)
- clsx (conditional classes)

---

## 💡 Design-principer

1. **Tydlighet över finess** - Funktionen ska vara uppenbar
2. **Status-driven design** - Färger och indikatorer visar tydligt vad som händer
3. **Progressive disclosure** - Tabs och funktioner aktiveras stegvis
4. **Minimal friction** - Drag & drop, bulk actions, shortcuts
5. **Feedback** - Loading states, progress bars, toast notifications

---

## 📸 Vad du behöver ta screenshots på

För att skapa en komplett mockup, fotografera:

1. **Projects-sidan** med flera projekt i olika states
2. **Ett projekt-card** som visar detailed progress bar
3. **Customer Import** med upload-area
4. **Matching-sidan** med resultat-tabell
5. **AI reviews** med queue status
6. **Export-sidan**
7. **Header navigation** i olika states (tabs enabled/disabled)
8. **Toast notifications** (success, error)
9. **Loading/processing states**

---

## 🎨 För Canva Mockup

**Rekommendationer:**

- Använd Canva's "Wireframe" eller "App Design" templates
- Fokusera på:
  - Tydlig visuell hierarki
  - Konsekvent användning av status-färger
  - Card-baserad layout
  - Whitespace mellan element
  - Hover- och active-states för interaktiva element

**Key screens att mocka:**
1. Projects overview
2. Import flow (upload → preview)
3. Matching results
4. AI review interface

---

## 📧 Kontakt

Om du har frågor om någon specifik funktionalitet eller interaktion, kontakta projektägaren.

**Datum:** 2025-10-13
**Version:** Current production version

